#include <iostream>

#include "hashmap.h"

using namespace std;

int main() {
  // Experimentation space!
}
